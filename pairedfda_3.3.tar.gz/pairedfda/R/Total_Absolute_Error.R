TAE <- function(data,para,ny,nz)
{
  ## Load dataset
  n = data$n
  y = data$y
  z = data$z
  By = data$B_y
  Bz = data$B_z
  nobs_y = data$nobs_y
  nobs_z = data$nobs_z
  
  ## Load parameters
  mu = para$theta_mu
  nu = para$theta_nu
  f  = para$theta_f
  g  = para$theta_g
  ka = ncol(f)
  kb = ncol(g)
  alpha = para$alpha
  beta  = para$beta 
  # Da = para$Da
  # Db = para$Db
  # C  = para$C
  # eps = para$sig_eps
  # xi  = para$sig_xi
  n_total_y = nrow(By)
  n_total_z = nrow(Bz)
  
  ## Estimate alpha & beta for test curves
  Bf    = By%*%f
  Bg    = Bz%*%g
  res_y = y - By%*%mu
  res_z = z - Bz%*%nu
  
  ## Create Augmented matrix Alpha and Beta
  Alpha = matrix(ncol = ka, nrow = n_total_y)
  for(i in 1:ka)
  {
    Alpha[,i]=rep(alpha[,i],nobs_y)
  }
  
  Beta = matrix(ncol = kb, nrow = n_total_z)
  for(i in 1:kb)
  {
    Beta[,i]=rep(beta[,i],nobs_z)
  }
  
  Bmu  = By%*%mu
  aBf  = apply(Alpha*(By%*%f),1,sum)
  yres = Bmu+aBf-y 
  w_y  = rep(1/ny, nobs_y)
  absy= sum(abs(yres) * w_y)
  
  Bnu  = Bz%*%nu
  bBg  = apply(Beta*(Bz%*%g),1,sum)
  zres = Bnu+bBg-z 
  w_z  = rep(1/nz, nobs_z)
  absz  = sum(abs(zres) * w_z)
  
  return(list(sy2 = absy,
              sz2 = absz))
}