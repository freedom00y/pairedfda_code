text = c("(1,1)","(1,2)","(1,3)","(2,1)","(2,2)","(2,3)","(3,1)","(3,2)","(3,3)")
n=500

files=c("t_0.04_510","t_0.25_530","s_0.04_530","s_0.25_530")
correct_rate=matrix(nrow=8,ncol=3)
####################################################
for(k in 1:4)
{
  if(k==1) nsamp=510
  if(k!=1) nsamp=530
  filename = files[k]
  A=read.table(paste0(filename,".txt"),skip=4,nrow=nsamp)
  A=as.matrix(A)
  A=A[!is.na(A[,2]),]
  neff = dim(A)[1]
  
  pdf(paste0(filename,"_small_gamma.pdf"))
  par(mfrow=c(5,3))
  par(mar=c(1,1,1,1))
  for(i in 1:n)
  {
    oneseed = A[i,1]
    oneres = as.vector(A[i,2:10])
    sortres = sort(oneres, decreasing = TRUE, index.return=TRUE)
    plot(1:length(sortres$x),sortres$x,'l',xlim=c(0,10))
    text(1:length(sortres$x)+0.2,sortres$x+0.2,text[sortres$ix])
    ind = which(sortres$ix==5)
    text(ind+0.2,sortres$x[ind]+0.2,"(2,2)",col="red")
  }
  dev.off()
  
  right_ratio1=c()
  for(q in c(0,0.01,0.05))
  {
    rightnum=0
    for(i in 1:n)
    {
      oneres = as.vector(A[i,2:10])
      threshold = (1+q)*min(oneres,na.rm=TRUE)
      
      if( (!is.na(oneres[5]) & oneres[5]<= threshold) & (oneres[1]>threshold | is.na(oneres[1])) & (oneres[2]> threshold | is.na(oneres[2])) & (oneres[4]> threshold| is.na(oneres[4])))
        rightnum=rightnum+1
    }
    right_ratio1=c(right_ratio1,rightnum/n)
  }
  correct_rate[2*k-1,]=right_ratio1
  
  ###############################################################
  A=read.table(paste0(filename,".txt"),skip=6+nsamp,nrow=nsamp)
  A=as.matrix(A)
  A=A[!is.na(A[,2]),]
  neff = dim(A)[1]
  pdf(paste0(filename,"_large_gamma.pdf"))
  par(mfrow=c(5,3))
  par(mar=c(1,1,1,1))
  for(i in 1:n)
  {
    oneseed = A[i,1]
    oneres = as.vector(A[i,2:10])
    sortres = sort(oneres, decreasing = TRUE, index.return=TRUE)
    plot(1:length(sortres$x),sortres$x,'l',xlim=c(0,10))
    text(1:length(sortres$x),sortres$x,text[sortres$ix])
    ind = which(sortres$ix==5)
    text(ind,sortres$x[ind],"(2,2)",col="red")
  }
  dev.off()
  
  right_ratio2=c()
  for(q in c(0,0.01,0.05))
  {
    rightnum=0
    for(i in 1:n)
    {
      oneres = as.vector(A[i,2:10])
      threshold = (1+q)*min(oneres,na.rm=TRUE)
      if( oneres[5]<= threshold & (oneres[1]>threshold | is.na(oneres[1])) & (oneres[2]> threshold | is.na(oneres[2])) & (oneres[4]> threshold| is.na(oneres[4])))
        rightnum=rightnum+1
    }
    right_ratio2=c(right_ratio2,rightnum/n)
  }
  correct_rate[2*k,]=right_ratio2
}

